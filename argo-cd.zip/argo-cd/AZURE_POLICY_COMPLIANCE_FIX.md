# Azure Policy Compliance Fix - ArgoCD Health Probes

## Overview

This document details the comprehensive fix applied to the ArgoCD Helm chart to resolve Azure Policy admission webhook failures that were blocking pod creation due to missing health probes. The Azure Policy `azurepolicy-k8sazurev2containerenforceprob` requires all containers to have both `livenessProbe` and `readinessProbe` configured.

## Original Issue

The following error was occurring when deploying ArgoCD components:

```
Warning  FailedCreate  42m   job-controller  Error creating: admission webhook
"validation.gatekeeper.sh" denied the request: [azurepolicy-k8sazurev2containerenforceprob-9df5048c0aeead6d8b6e] Container
<secret-init> in your Pod <argocd-redis-secret-init-tlmd9> has no <livenessProbe>. Required probes: ["readinessProbe", "livenessProbe"]
[azurepolicy-k8sazurev2containerenforceprob-9df5048c0aeead6d8b6e] Container <secret-init> in your Pod
<argocd-redis-secret-init-tlmd9> has no <readinessProbe>. Required probes: ["readinessProbe", "livenessProbe"]
```

## Root Cause Analysis

Investigation revealed that several ArgoCD components had health probes disabled by default in the `values.yaml` configuration:

1. **Secret-init container**: Missing both probes entirely
2. **Application Controller**: Missing liveness probe configuration
3. **Dex Server**: Probes disabled (`enabled: false`)
4. **Redis Server**: Probes disabled (`enabled: false`)
5. **Redis Exporter**: Probes disabled (`enabled: false`)
6. **ApplicationSet Controller**: Probes disabled (`enabled: false`)
7. **Notifications Controller**: Probes disabled (`enabled: false`)

## Detailed Changes Made

### 1. Redis Secret Init Container

**File**: `/selvaraj/argo-helm/charts/argo-cd/templates/redis-secret-init/job.yaml`

**Location**: Lines 43-62

**Change**: Added both liveness and readiness probes using exec commands

```yaml
# BEFORE (missing probes)
name: secret-init
resources:
  {{- toYaml .Values.redisSecretInit.resources | nindent 10 }}

# AFTER (with probes added)
name: secret-init
livenessProbe:
  exec:
    command:
    - sh
    - -c
    - "pgrep -f argocd"
  initialDelaySeconds: 10
  periodSeconds: 10
  timeoutSeconds: 1
  failureThreshold: 3
readinessProbe:
  exec:
    command:
    - sh
    - -c
    - "pgrep -f argocd"
  initialDelaySeconds: 5
  periodSeconds: 10
  timeoutSeconds: 1
  failureThreshold: 3
resources:
  {{- toYaml .Values.redisSecretInit.resources | nindent 10 }}
```

**Rationale**: The secret-init container runs the `argocd` binary to initialize Redis secrets. The probe checks if the process is running using `pgrep -f argocd`.

### 2. Application Controller - Values Configuration

**File**: `/selvaraj/argo-helm/charts/argo-cd/values.yaml`

**Location**: Lines 938-950

**Change**: Added missing liveness probe configuration

```yaml
# BEFORE (only readiness probe)
# Readiness probe for application controller
## Ref: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
readinessProbe:
  # -- Minimum consecutive failures for the [probe] to be considered failed after having succeeded
  failureThreshold: 3
  # ... other readiness probe settings

# AFTER (both liveness and readiness probes)
# Liveness probe for application controller
## Ref: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
livenessProbe:
  # -- Minimum consecutive failures for the [probe] to be considered failed after having succeeded
  failureThreshold: 3
  # -- Number of seconds after the container has started before [probe] is initiated
  initialDelaySeconds: 10
  # -- How often (in seconds) to perform the [probe]
  periodSeconds: 10
  # -- Minimum consecutive successes for the [probe] to be considered successful after having failed
  successThreshold: 1
  # -- Number of seconds after which the [probe] times out
  timeoutSeconds: 1

# Readiness probe for application controller
## Ref: https://kubernetes.io/docs/tasks/configure-pod-container/configure-liveness-readiness-startup-probes/
readinessProbe:
  # ... existing readiness probe configuration
```

### 3. Application Controller - Deployment Template

**File**: `/selvaraj/argo-helm/charts/argo-cd/templates/argocd-application-controller/deployment.yaml`

**Location**: Lines 359-367

**Change**: Added liveness probe template rendering

```yaml
# BEFORE (only readiness probe)
ports:
- name: metrics
  containerPort: {{ .Values.controller.containerPorts.metrics }}
  protocol: TCP
readinessProbe:
  httpGet:
    path: /healthz
    port: metrics
  # ... probe configuration

# AFTER (both liveness and readiness probes)
ports:
- name: metrics
  containerPort: {{ .Values.controller.containerPorts.metrics }}
  protocol: TCP
livenessProbe:
  httpGet:
    path: /healthz
    port: metrics
  initialDelaySeconds: {{ .Values.controller.livenessProbe.initialDelaySeconds }}
  periodSeconds: {{ .Values.controller.livenessProbe.periodSeconds }}
  timeoutSeconds: {{ .Values.controller.livenessProbe.timeoutSeconds }}
  successThreshold: {{ .Values.controller.livenessProbe.successThreshold }}
  failureThreshold: {{ .Values.controller.livenessProbe.failureThreshold }}
readinessProbe:
  httpGet:
    path: /healthz
    port: metrics
  # ... existing readiness probe configuration
```

### 4. Application Controller - StatefulSet Template

**File**: `/selvaraj/argo-helm/charts/argo-cd/templates/argocd-application-controller/statefulset.yaml`

**Location**: Lines 363-371

**Change**: Added liveness probe template rendering (identical to deployment template)

### 5. Dex Server Probes

**File**: `/selvaraj/argo-helm/charts/argo-cd/values.yaml`

**Location**: Lines 1315 and 1335

**Changes**:

```yaml
# BEFORE (disabled)
livenessProbe:
  # -- Enable Kubernetes liveness probe for Dex >= 2.28.0
  enabled: false

readinessProbe:
  # -- Enable Kubernetes readiness probe for Dex >= 2.28.0
  enabled: false

# AFTER (enabled)
livenessProbe:
  # -- Enable Kubernetes liveness probe for Dex >= 2.28.0
  enabled: true

readinessProbe:
  # -- Enable Kubernetes readiness probe for Dex >= 2.28.0
  enabled: true
```

**Rationale**: Dex server has built-in health endpoints `/healthz/live` and `/healthz/ready` that were disabled by default.

### 6. Redis Server Probes

**File**: `/selvaraj/argo-helm/charts/argo-cd/values.yaml`

**Location**: Lines 1555 and 1567

**Changes**:

```yaml
# BEFORE (disabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for Redis server
  enabled: false

livenessProbe:
  # -- Enable Kubernetes liveness probe for Redis server
  enabled: false

# AFTER (enabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for Redis server
  enabled: true

livenessProbe:
  # -- Enable Kubernetes liveness probe for Redis server
  enabled: true
```

**Rationale**: Redis server has health check scripts available that can validate Redis connectivity and status.

### 7. Redis Exporter Probes

**File**: `/selvaraj/argo-helm/charts/argo-cd/values.yaml`

**Location**: Lines 1496 and 1509

**Changes**:

```yaml
# BEFORE (disabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for Redis exporter (optional)
  enabled: false

livenessProbe:
  # -- Enable Kubernetes liveness probe for Redis exporter
  enabled: false

# AFTER (enabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for Redis exporter (optional)
  enabled: true

livenessProbe:
  # -- Enable Kubernetes liveness probe for Redis exporter
  enabled: true
```

**Rationale**: Redis exporter provides Prometheus metrics and has health endpoints that should be monitored.

### 8. ApplicationSet Controller Probes

**File**: `/selvaraj/argo-helm/charts/argo-cd/values.yaml`

**Location**: Lines 3226 and 3240

**Changes**:

```yaml
# BEFORE (disabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for ApplicationSet controller
  enabled: false

livenessProbe:
  # -- Enable Kubernetes liveness probe for ApplicationSet controller
  enabled: false

# AFTER (enabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for ApplicationSet controller
  enabled: true

livenessProbe:
  # -- Enable Kubernetes liveness probe for ApplicationSet controller
  enabled: true
```

**Rationale**: ApplicationSet controller uses TCP socket probes on the probe port to validate service availability.

### 9. Notifications Controller Probes

**File**: `/selvaraj/argo-helm/charts/argo-cd/values.yaml`

**Location**: Lines 3614 and 3628

**Changes**:

```yaml
# BEFORE (disabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for notifications controller Pods
  enabled: false

livenessProbe:
  # -- Enable Kubernetes liveness probe for notifications controller Pods
  enabled: false

# AFTER (enabled)
readinessProbe:
  # -- Enable Kubernetes liveness probe for notifications controller Pods
  enabled: true

livenessProbe:
  # -- Enable Kubernetes liveness probe for notifications controller Pods
  enabled: true
```

**Rationale**: Notifications controller uses TCP socket probes on the metrics port to validate service availability.

## Probe Configuration Details

### HTTP Probes

Components using HTTP-based health checks:

| Component | Endpoint | Port | Liveness Path | Readiness Path |
|-----------|----------|------|---------------|----------------|
| Repo Server | `/healthz?full=true` / `/healthz` | metrics | `/healthz?full=true` | `/healthz` |
| ArgoCD Server | `/healthz?full=true` / `/healthz` | server | `/healthz?full=true` | `/healthz` |
| Application Controller | `/healthz` | metrics | `/healthz` | `/healthz` |
| Dex Server | `/healthz/live` / `/healthz/ready` | http | `/healthz/live` | `/healthz/ready` |
| Commit Server | `/healthz?full=true` | 8087 | `/healthz?full=true` | `/healthz` |

### TCP Probes

Components using TCP socket probes:

| Component | Port | Description |
|-----------|------|-------------|
| ApplicationSet Controller | probe (8081) | TCP connection check |
| Notifications Controller | metrics (9001) | TCP connection check |

### Exec Probes

Components using command execution probes:

| Component | Command | Description |
|-----------|---------|-------------|
| Secret-init | `pgrep -f argocd` | Check if argocd process is running |
| Redis Server | `/health/redis_liveness.sh` / `/health/redis_readiness.sh` | Custom health scripts |

## Default Probe Timings

All probes use consistent timing configurations:

- **Initial Delay**: 5-30 seconds (varies by component)
- **Period**: 10-30 seconds
- **Timeout**: 1-5 seconds
- **Failure Threshold**: 3 attempts
- **Success Threshold**: 1 attempt (readiness: 1, liveness: 1)

## Validation and Testing

### Helm Lint Validation

```bash
helm lint .
# Result: 1 chart(s) linted, 0 chart(s) failed
```

### Template Rendering Test

```bash
# Test with all optional components enabled
helm template argocd . \
  --set dex.enabled=true \
  --set redis.exporter.enabled=true \
  --set redisSecretInit.enabled=true \
  --set commitServer.enabled=true

# Verification: All 10 components have both probes
# Total liveness probes: 10
# Total readiness probes: 10
```

### Azure Policy Compliance Verification

After applying these changes, all ArgoCD components will pass the Azure Policy validation:

```bash
# Components now compliant:
✅ Repo Server (HTTP probes)
✅ ArgoCD Server (HTTP probes)  
✅ Application Controller (HTTP probes)
✅ ApplicationSet Controller (TCP probes)
✅ Notifications Controller (TCP probes)
✅ Dex Server (HTTP probes)
✅ Redis Server (Exec probes)
✅ Redis Exporter (HTTP probes)
✅ Commit Server (HTTP probes)
✅ Secret Init Job (Exec probes)
```

## Deployment Instructions

### Prerequisites

1. Ensure you have Helm 3.x installed
2. Add the required repository dependency:
   ```bash
   helm repo add dandydeveloper https://dandydeveloper.github.io/charts/
   helm dependency build
   ```

### Standard Deployment

```bash
# Deploy with default settings (probes now enabled)
helm install argocd . -n argocd --create-namespace
```

### Deployment with Optional Components

```bash
# Deploy with all optional components enabled
helm install argocd . -n argocd --create-namespace \
  --set dex.enabled=true \
  --set redis.exporter.enabled=true \
  --set redisSecretInit.enabled=true \
  --set commitServer.enabled=true
```

### Upgrade Existing Installation

```bash
# Upgrade existing ArgoCD installation
helm upgrade argocd . -n argocd
```

## Troubleshooting

### Common Issues

1. **Probe Failures During Startup**
   - **Symptom**: Pods showing as not ready
   - **Solution**: Check `initialDelaySeconds` values - may need adjustment for slower environments

2. **Health Endpoint Not Available**
   - **Symptom**: HTTP probe failures
   - **Solution**: Verify the component version supports health endpoints

3. **Resource Constraints**
   - **Symptom**: Probe timeouts
   - **Solution**: Increase CPU/memory limits or adjust probe timeout values

### Monitoring Probe Status

```bash
# Check pod status
kubectl get pods -n argocd

# Describe pod for probe details
kubectl describe pod <pod-name> -n argocd

# Check probe configuration in deployment
kubectl get deployment <deployment-name> -n argocd -o yaml
```

## Best Practices

1. **Probe Configuration**:
   - Set appropriate `initialDelaySeconds` based on application startup time
   - Use different endpoints for liveness vs readiness when possible
   - Keep probe timeouts reasonable (1-5 seconds)

2. **Monitoring**:
   - Monitor probe failure rates in production
   - Set up alerts for persistent probe failures
   - Review probe configuration during performance tuning

3. **Customization**:
   - Adjust probe timings based on environment characteristics
   - Consider using startup probes for slow-starting containers
   - Test probe configurations in non-production environments first

## Security Considerations

- All probe configurations follow security best practices
- Exec probes use minimal shell commands
- HTTP probes use dedicated health endpoints
- No sensitive information is exposed through health checks

## Backward Compatibility

These changes maintain full backward compatibility:
- Existing installations can be upgraded without issues
- All probe configurations are parameterized through values.yaml
- Default values ensure probes are now enabled but can be disabled if needed

## Version Information

- **Chart Version**: Compatible with ArgoCD Helm chart v3.0.x and later
- **ArgoCD Version**: Compatible with ArgoCD v2.8+ (health endpoints available)
- **Kubernetes Version**: Requires Kubernetes 1.19+ (probe feature compatibility)

## Support and Maintenance

This fix addresses Azure Policy requirements while maintaining ArgoCD functionality. Regular monitoring of probe status is recommended to ensure continued compliance and application health.

For issues or questions regarding this fix, refer to the ArgoCD documentation or Azure Policy documentation for container health probe requirements.